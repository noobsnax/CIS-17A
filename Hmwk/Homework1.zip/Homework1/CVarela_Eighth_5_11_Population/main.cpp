#include <cstdlib>
#include <iostream>
#include <cmath>
using namespace std;

int main(int argc, char** argv) {
    
    int startsize = 0;
    int avggrowth = 0;
    int numberofdays = 0;
    
    cout << "Give me a start count for the number of starting organisms: ";
    cin >> startsize;
    
    /*if start size is less than two, close the program*/
    if(startsize < 2)
    {
        cout << "This organism needs a partner to multiply, Sir" ;
                return 0;
    }
    
    cout << "What is their average daily population growth: ";
    cin >> avggrowth;
    
    /*if avg growth is less than 0, close the program*/
    if (avggrowth < 0)
    {
        cout << "Give me a positive value" ;
        return 0;
    }
    
    cout << "how many days will they multiply: ";
    cin >> numberofdays;
    
    /*if number of days is less than 1, close the program*/
    if (numberofdays < 1)
    {
        cout << "they will not go extinct tomorrow..";
                return 0;
    }
    
    /*multiply growth by the start size9*/
    avggrowth = (avggrowth*startsize) * .01;
    for(int count = 1; count <= numberofdays; count++)
    {
        cout << "# of Days: " << count;   
        startsize = startsize + avggrowth;
        cout << "\t" << startsize << endl;
    }
    return 0;
}

