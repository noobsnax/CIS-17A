#include <iostream>
#include <cstdlib>
#include <fstream>
#include <iomanip>
using namespace std;

int main(int argc, char** argv) {
    
    const int MONTH = 3;
    const int DAYS = 30;
    char weather[MONTH][DAYS];
    
    int sun,
            rain,
            clouds,
            totalsun = 0,
            totalrain = 0,
            totalclouds = 0,
            mostrain = 0;
    
    /*Create object inputfile. Open the file.
     if inputfile doesn't open, display error prompt
     else, iterate through text file filling array contents
     into weather array, then close the file*/
    
    ifstream inputfile; //create object to input
    inputfile.open("rainorshine.txt"); // open file
    if(!inputfile)
        cout << "i had an issue opening the file";
    else
    {
        for (int i = 0; i<MONTH;i++)
        {
            for (int j=0;j<DAYS;j++)
            {
                inputfile >> weather[i][j];
            }
        }
    }inputfile.close();     //close the file
    
    cout << "Display Values for the Months.\n\n";
    
    for(int i = 0; i < MONTH; i++)
    { 
        sun = rain = clouds = 0;
        for (int j = 0; j < DAYS; j++)
        {
            switch(weather[i][j])
            {
                case 'S' : sun++; //case S to add for variable sun, etc
                    break;
                case 'R' : rain++;
                    break;
                case 'C' : clouds++;
                    break;
            }
        }
        
        //Assign which month according to value of index array
        if(i == 0)
            cout << "June\n";
        else if(i==1)
            cout << "July\n";
        else if(i==2)
            cout << "August\n";
        
        //display values per weather condition
        cout << "Sunny  : " << setw(3)<< sun << endl;
        cout << "Rainy  : " << setw(3)<< rain << endl;
        cout << "Clouds : " << setw(3)<< clouds << "\n" << endl;
        
        //calculate summation of weather conditions for three month period
        totalsun += sun;
        totalrain += rain;
        totalclouds += clouds;
        
        //determine which month had the most rain
        if (mostrain > rain)
            mostrain = i;
    }
    
    //output weather conditions for three month period
    cout << "Totals for 3-Month Period\n";
    cout << "Sunny  : " << setw(3)<< totalsun << endl;
    cout << "Rainy  : " << setw(3)<< totalrain << endl;
    cout << "Clouds : " << setw(3)<< totalclouds << endl;
    
    //output which month has the most rain by checking value stored in variable mostrain
    cout << "\nMonth with largest amount of rainy days : ";
        if(mostrain == 0)
            cout << "June\n";
        else if(mostrain == 1)
            cout << "July\n";
        else if(mostrain == 2)
            cout << "August\n";
        
    return 0;
}
