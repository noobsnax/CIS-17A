#include<iostream>
#include<iomanip>
using namespace std;

int main(int argc, char** argv) {

    //declares both to be floats for accuracy
    float fahrenheit = 0;
    float celsius = 0;
    
    cout << "Enter the temperature in celsius you would like to convert " << endl;
    cin >> celsius ;
    //takes in user input for celsius temperature and calculates conversion accordingly
    fahrenheit = (9 * celsius) / 5 + 32;
    //sets width, determines showpoint and precision values
    cout << showpoint << setprecision(4) << setw(4);
    
    //outputs fahrenheit after calculation
    cout << "The temperature in F is: " << fahrenheit << endl;
            
    return 0;
}

