#include <iostream>
#include <cstdlib>

using namespace std;

int main(int argc, char** argv) {

    int month = 0;
    int year = 0;

    cout << "Enter a month (1 - 12): ";
    cin >> month ;
    
    //check if month is in bounds, terminate if false
    if(month<=0||month>12)
    {
        cout << "Enter a month that exists please, Sir" << endl;
        return 0;
    }

    cout << "Enter a year: " ;   
    cin >> year ;
   
    //check if year is in bounds, terminate if false
    if(year<=0)
    {
        cout << "Enter a year in A.D. please, Sir" << endl;
        return 0;
    }
    //if month is odd, less than and equal to five 
    //or even and greater then and equal to 8, output 31
    if (((month % 2 == 1) && month <= 5) || (month % 2 == 0) && month >= 8)
        cout << "31 days";
    
    //else if month is even, not 2, and less than equal to 6
    //or greater than or equal to 9, output 30
    else if ((month % 2 == 0) && month != 2 && month <= 6 || month >= 9)
        cout << "30 days";
    
    //else if two and not a leap year output 28
    else if ((month == 2) && (year % 100 == 0))
        cout << "28 days";
    
    //else if its a leap year it must be divisible by 400 or 4
    else if ((month == 2) && (year % 400 == 0) || (year % 4 == 0))
        cout << "29 days";
    
    //this is kind of a fall through, if the year is odd output 28
    else if ((month == 2) && (year / 2 != 0))
        cout << "28 days";
   
return 0;   
}