#include <iostream>
#include <iomanip>
using namespace std;

int main(int argc, char** argv) {

    //declares constants for dollar conversions
    const float YEN_PER_DOLLAR = 106.92;
    const float EUROS_PER_DOLLAR = 0.91;
    const float US_DOLLAR = 1.00;
    const int SIZE = 5;
    
    //declares temp for user input
    float temp = 0;
    
    //toEuro and toYen to hold conversion 
    float toEuro = 0;
    float toYen =0;
    
    cout << "Enter the amount of money in US dollars you wish to convert" << endl;
    cin >> temp;
    
    //sets width to equal constant 5, notice the decimal.
    //the decimal is noticed
    cout << setw(SIZE) << setprecision(2) << fixed << showpoint << right;
    
    cout << "Amount in Yen:  ";
    //temp multiplied by conversion constant, then outputted
    toYen = (temp*YEN_PER_DOLLAR);
    cout << "\t" << toYen << endl;
   
    cout << "Amount in Euro: ";
    //temp multiplied by conversion constant, then outputted
    toEuro = (temp*EUROS_PER_DOLLAR);
    cout << "\t" << toEuro << endl;
    
    return 0;
}
