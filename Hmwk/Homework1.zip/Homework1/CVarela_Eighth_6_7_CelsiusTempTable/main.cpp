#include <iostream>
#include <cstdlib>
#include <iomanip>
using namespace std;

//function prototype for celsius
float celsius(int fnum);

int main(int argc, char** argv) {
    
    cout << "Temperatures" << endl;
    cout << "=================================================" << endl;

    //for loop to output 1 - 20
    for (int count = 1;count<=20;count++)
    {
        /* call celsius to hold new value of converted temp
         * into celsiusconv until the loop of 20 is reached
         */ 
        float celsiusconv = celsius(count);
        cout << fixed << right << showpoint << setprecision(2);
        cout << "Fahrenheit:\t" << count << "\t";
        cout << "Celsius:\t" << celsiusconv << endl;
    }
    
    return 0;
}

//function celsius takes a int fahrenhiet from 1-20 and returns float
//of new celsius value
float celsius(int fnum)
{
    float c = ((static_cast<float>(fnum) - 32)*5)/9;
    return c;
}